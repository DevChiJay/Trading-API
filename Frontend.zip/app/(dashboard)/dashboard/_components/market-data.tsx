import { MarketData } from "react-ts-tradingview-widgets";

export const MarketDataWidget = () => {
  return <MarketData colorTheme="dark" width="100%" height="100%"></MarketData>;
};

