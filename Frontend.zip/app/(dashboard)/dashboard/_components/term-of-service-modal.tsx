import React from 'react'

const TermOfServiceModal = () => {
  return (
    <div>TermOfServiceModal</div>
  )
}

export default TermOfServiceModal